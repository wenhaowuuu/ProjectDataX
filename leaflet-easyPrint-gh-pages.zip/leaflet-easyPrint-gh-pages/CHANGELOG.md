# Changelog

version 2
22/07/2017
- Complete overhaul
- Now using the excellent dom-to-image library
- Ability to both print and export
- Programmatic access
- Resizing 